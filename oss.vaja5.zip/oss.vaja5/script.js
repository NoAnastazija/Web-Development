// Saves list of categories HTML content ul
function saveUl() {
    localStorage.setItem("list", $("ul").html());

}

// Saves HTML content and gets it table
function saveTb() {
    localStorage.setItem("table", $("table").html());
}

// Loads previously saved content
function load() {
    if (localStorage.getItem("list")) {
        $("ul").html(localStorage.getItem("list"))
    }
    if (localStorage.getItem("table")) {
        $("table").html(localStorage.getItem("table"))
    }
}

// Updates tabelaopravil iterates over each row
// in tables body and updates the text of each cell in row index plus 1
// after updating calls savetb to save 
function posodobiStevilke() {
    $("#tabelaOpravil tbody tr").each(function (index) {
        $(this).find("td:first").text(index + 1);
        saveTb();
    });
}

// jquery, executes when DOM is fully loaded, calls load
$(document).ready(function () {
    load();

    // Add new category to ul
    $("#dodajKat").click(function dodajKategorijo() {
        let novo = $("#novaKategorija").val();
        $("ul").append("<li class='list-group-item'>" + novo + "</li>");
        saveUl();
    });

    // Handles click events forr category list
    $("ul").on("click", "li", function () {
        $("ul li").removeAttr("id"); //odstrani od drugih,
        $("ul li").css("font-weight", "normal");
        $("ul li").removeClass("list-group-item active");
        $("ul li").addClass("list-group-item");
        $(this).css("font-weight", "bold");
        $(this).attr("id", "izbran");
        $(this).addClass("list-group-item active");
    });
    // Ibrisi kat
    $("#izbrisiKat").click(function izbrisiKategorijo() {
        $("#confirmationModal").modal("show");
        $("#potrdiIzbris").click(function () {
            $(".izbran").remove();
            $("#izbran").remove();
            saveUl();

        });
    });

    let counter = 1;
    // Adds new task
    $("#dodajOpr").click(function dodajOpravilo() {
        let opis = $("#novoOpravilo").val();
        let kategorija = $("ul li#izbran").text();
        let cas = new Date().toLocaleString();
        $("#tabelaOpravil tbody").append(
            `<tr>
                <td>${counter}</td>
                <td>${opis}</td>
                <td>${kategorija}</td>
                <td>${cas}</td>
            </tr>`
        ); counter++;
        saveTb();
    });
    // Click events, marks reed and bolt
    $("tbody").on("click", "tr", function () {
        $(this).css("font-weight", "bold")
        $(this).addClass("izbrano");
        $(this).addClass("table-danger");

    });
    // Confirmation for deleting a task
    $("#izbrisiOpr").click(function izbrisiOpravilo() {
        $('#confirmationModal').modal('show');
    });
    $("#potrdiIzbris").click(function () {
        $(".izbrano").remove();
        posodobiStevilke();
        saveTb(); 
        $('#confirmationModal').modal('hide');
    });
    $("#x").click(function () {
        $('#confirmationModal').modal('hide');
    });
    $("#preklici").click(function () {
        $('#confirmationModal').modal('hide');
    });

});


